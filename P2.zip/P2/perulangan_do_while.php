<?php

$i = 1;

do{
    echo "Nilai ke : $i<br>";
    $i++;
}while($i <= 10);

?>