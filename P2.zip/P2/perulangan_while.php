<?php
echo "Cara Pertama <br>";
$i = 1;
while($i<=10){

    echo "Nilai ke : $i<br>";
    $i++;
    
}

echo "Cara Kedua <br>";
$i2 = 1;
while($i2 <= 10):
    echo "Nilai ke : $i2 <br>";
    $i2++;
endwhile;
?>