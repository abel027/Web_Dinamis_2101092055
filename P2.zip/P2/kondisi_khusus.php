<?php
$nilai = 85;
$status="";

($nilai > 80) ? $status = "Lulus" : $status = "Gagal";

echo "Nilai $nilai, Dengan Status : $status";

?>