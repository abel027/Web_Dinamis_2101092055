<?php

$nilai = 90;
if($nilai > 80){
    $status = "lulus";
}

echo "status Kelulusan : $status";

?>